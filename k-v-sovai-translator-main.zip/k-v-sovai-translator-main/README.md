#  Subject: Advanced AI PROJECT 2025

Prof: Hyung–Jeong Yang

## Task: Development of a Special-Language Translation AI Model Using Sovereign AI Open-Source LLM
##       소버린 AI를 활용한 특수언어 번역 AI 모델 개발 오픈 소스 LLM

Name: Kim Ngan Phan

⛔ ***Only used for demonstration of the subject***

This code is used for mobile app
